<?php include 'header.php'; ?>

<!-- inicio pagina -->
<div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
  <div class="pginicial">
    <div class="container"> <br>
      <div class="">
        <h1>Você não possui grades horárias cadastradas</h1>
        
        <hr>
        
        <h2>Siga esses passos para criar sua grade horária</h2>
      <div class="row mb-3 ">
        <div class="col-lg-4 col-md-4 col-xl-4 col-sm-12 themed-grid-col"> <a href="professores.php">
          <div class="h-100 p-5 bg-body-tertiary border rounded-3">
            <h4>Passo 1</h4>
            <img src="img/icone-professor.png" width="100" height="100" alt=""/>
            <h2>Cadastre seus professores </h2>
          </div>
          </a> </div>
        <div class="col-lg-4 col-md-4 col-xl-4 col-sm-12  themed-grid-col"> <a href="turmas.php">
          <div class="h-100 p-5 bg-body-tertiary border rounded-3">
            <h4>Passo 2</h4>
            <img src="img/icone-turma.png" width="100" height="100" alt=""/>
            <h2>Cadastre suas turmas</h2>
          </div>
          </a> </div>
        <div class="col-lg-4 col-md-4 col-xl-4 col-sm-12  themed-grid-col"> <a href="grades-horarias.php">
          <div class="h-100 p-5 bg-body-tertiary border rounded-3">
            <h4>Passo 3</h4>
            <img src="img/gerar-grade.png" width="100" height="100" alt=""/>
            <h2>Gere sua grade Horária</h2>
          </div>
          </a> </div>
      </div>
      </div>
     



<?php include 'footer.php'; ?>
