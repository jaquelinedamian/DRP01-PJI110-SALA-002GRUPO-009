<?php include 'header.php'; ?>
<!-- inicio pagina --> 

<div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
<br>
	 <div class="container">
    <h1>Perfil</h1>
    <form>
      <img src="https://github.com/mdo.png" alt="mdo" width="100" height="100" class="rounded-circle"> <br>
      <div class="mb-3"> <br>
        <div class="input-group input-group-lg"> <span class="input-group-text" id="inputGroup-sizing-lg">Nome</span>
          <input class="form-control" type="text" value="Manuel da Silva" aria-label="" disabled readonly>
        </div>
        <br>
        <div class="input-group input-group-lg"> <span class="input-group-text" id="inputGroup-sizing-lg">E-mail</span>
          <input class="form-control" type="text" value="manuel@email.com.br" aria-label="" disabled readonly>
        </div>
      </div>
      <a href="#">
      <button type="button" class="btn btn-primary">Editar</button>  </a>
       <a href="#">
      
       <button type="button" class="btn btn-primary">Salvar</button>
    </a>
    </form>
  </div>
  <br> <br> <br> <br>
  <!-- fim pagina --> 
</div>
<?php include 'footer.php'; ?>
