<form method="post" action="gravar_professor_horarios.php">
    <!-- Campos para o cadastro do professor -->
    <div class="col-12 col-sm-12 col-md-8 col-lg-8 col-xl-8 col-xxl-8">
        <div class="input-group flex-nowrap"> <span class="input-group-text">Nome do professor</span>
            <input type="text" class="form-control" name="nome_professor">
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
        <div class="input-group flex-nowrap"> <span class="input-group-text">Total de horas por semana</span>
            <input type="text" class="form-control" name="total_horas_semana">
        </div>
    </div>
    <!-- Campos para seleção dos horários -->
    <!-- Restante do formulário -->
    <!-- Adicione um campo oculto para enviar os horários selecionados -->
    <?php
    foreach ($dias_da_semana as $dia) {
        for ($i = 1; $i <= 5; $i++) {
            echo '<input type="hidden" name="horarios[]" value="' . $dia . '-' . $i . '">';
        }
    }
    ?>
    <!-- Botão de submit -->
    <button type="submit" class="btn btn-primary">Gravar Professor e Horários</button>
</form>
