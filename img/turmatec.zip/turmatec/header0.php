<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="Alunos Univesp">
<link rel="icon" type="image/png" href="img/favicon.png">
<title>TurmaTec - Login</title>
<link href="css/sign-in.css" rel="stylesheet">
<link rel="stylesheet" href="css/css@3">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/customstyle.css" rel="stylesheet">
<link href="css/headers.css" rel="stylesheet">
	</head>
	<body>
<header class="border-bottom text-bg-dark menuicon">

<div class="container">
  <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
    <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 col-xxl-3"> <a href="index.html" class="text-decoration-none nav-link text-white">
      <button>
           <a href="index.php">
          <img src="img/logobranco.svg" alt="logo" width="150" > </a></button>
      
      
      </div>
      
    <div class="col-1 col-sm-1 col-md-8 col-lg-8 col-xl-8 col-xxl-8"></div>
    <div class="col-12 col-sm-12 col-md-1 col-lg-1 col-xl-1 col-xxl-1">

    </div>
  </div>
</div>
</header>